const attivoSoloSuNolexViewer = true
const aperturaAutomaticaFullScreen = true

// salvo la posizione e le dimensioni della finestra corrente
async function salvaFinestra() {
  const currentWindow = await chrome.windows.getCurrent();
  const finestraData = {
    left: currentWindow.left,
    top: currentWindow.top,
    width: currentWindow.width,
    height: currentWindow.height
  };

  // salvo i dati nel chrome.storage
  await chrome.storage.local.set({ finestraData });
  console.log("Preferenze finestra salvate:", finestraData);
}

async function eliminaConfigurazione() {
  await chrome.storage.local.remove('finestraData');
  console.log("Configurazione eliminata");
}


//Invio info monitor
async function getInfoMonitor() {
  chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
    if (tabs.length > 0) {
      const monitorInfo = await chrome.system.display.getInfo()
      console.log(monitorInfo)
      chrome.tabs.sendMessage(tabs[0].id, {
        type: "monitorInfo",
        data: { monitors: JSON.stringify(monitorInfo) }
      });
    }
  });
}

// ripristino la posizione e le dimensioni salvate
async function ripristinaFinestra() {

  // Ottengo la scheda attualmente attiva
  const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });

  if (!activeTab) {
    console.log("Nessuna scheda attiva visualizzatore Nolex trovata.");
    return;
  }

  if (attivoSoloSuNolexViewer && activeTab.url && !activeTab.url.includes('/nolexviewer/')) {
    console.log("Nessuna scheda attiva visualizzatore Nolex trovata.");
    return;
  }
  // recupero i dati salvati
  chrome.storage.local.get("finestraData", (result) => {
    if (!result.finestraData) { //Nessuna configurazione salvata
      return console.log("Nessuna posizione e dimensioni salvate trovate.");
    }

    //invio al client la configurazione attuale salvata
    chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
      if (tabs.length > 0) {
        chrome.tabs.sendMessage(tabs[0].id, {
          type: "configAttuale",
          data: { configAttuale: result.finestraData }
        });
      }
    });

    const { left, top, width, height } = result.finestraData;

    // Ottengo i dettagli della finestra attiva
    chrome.windows.getCurrent({ populate: true }, (currentWindow) => {
      const currentLeft = currentWindow.left;
      const currentTop = currentWindow.top;
      const currentWidth = currentWindow.width;
      const currentHeight = currentWindow.height;

      // Verifico se le dimensioni e la posizione corrispondono a quelle salvate, se fosse così non è necessario applicare alcuna modifica
      if (
        currentLeft === left &&
        currentTop === top &&
        currentWidth === width &&
        currentHeight === height
      ) {
        console.log("La finestra attiva ha già la configurazione desiderata.");
        return;
      }

      //Devo applicare le modifiche, creo una nuova finestra con la scheda attuale
      chrome.windows.create({ tabId: activeTab.id }, async (newWindow) => {

        console.log("Scheda spostata in una nuova finestra:", newWindow);

        // controllo se la finestra è massimizzata
        if (newWindow.state === "maximized") {
          // Prima di applicare le dimensioni, ripristino lo stato normale
          chrome.windows.update(newWindow.id, { state: "normal" }, () => {
            // Applico dimensioni e posizione
            chrome.windows.update(newWindow.id, { left, top, width, height }, () => {
              console.log("Posizione e dimensioni ripristinate:", result.finestraData);
              if (aperturaAutomaticaFullScreen) {
                chrome.windows.update(newWindow.id, { state: "fullscreen" });
              }
            });
          });
        } else {
          // Se non è massimizzata applico direttamente le dimensioni e la posizione
          chrome.windows.update(newWindow.id, { left, top, width, height }, () => {
            console.log("Posizione e dimensioni ripristinate:", result.finestraData);
            if (aperturaAutomaticaFullScreen) {
              chrome.windows.update(newWindow.id, { state: "fullscreen" });
            }
          });
        }
        //Invio alla pagina web avvenuta modifica
        chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
          if (tabs.length > 0) {
            chrome.tabs.sendMessage(tabs[0].id, {
              type: "applicazioneModifiche",
              data: { applicazioneModifiche: 'ok' }
            });
          }
        });
      })
    });
  })
}

async function impostaFullScreenCorrente() {
  if (!aperturaAutomaticaFullScreen) {
    return;
  }
  chrome.windows.getCurrent((currentWindow) => {
    if (currentWindow.state !== "fullscreen") {
      chrome.windows.update(currentWindow.id, { state: "fullscreen" });
    }
  });
}

chrome.action.onClicked.addListener(() => {
  salvaFinestra();
});

//Al caricamento pagina
chrome.webNavigation.onCompleted.addListener((details) => {
  if (!attivoSoloSuNolexViewer || (attivoSoloSuNolexViewer && details.url.includes('nolexviewer'))) {
    console.log("Pagina caricata:", details.url);
    getInfoMonitor()
    ripristinaFinestra();
    impostaFullScreenCorrente();
  }
});


chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log("background: message ricevuto", message, "sender", sender?.tab?.id, sender?.tab?.windowId);
  if (message.type === "exitFullscreen" || message.type === "toggleFullscreen") {
    const handleWindow = (win) => {
      if (!win) {
        console.log("toggleFullscreen: finestra non trovata");
        sendResponse({ status: "error", message: "Finestra non trovata" });
        return;
      }
      console.log("toggleFullscreen: stato attuale", win.state, "id", win.id);
      if (message.type === "toggleFullscreen") {
        const nextState = win.state === "fullscreen" ? "normal" : "fullscreen";
        chrome.windows.update(win.id, { state: nextState }, () => {
          if (chrome.runtime.lastError) {
            console.log("toggleFullscreen: errore update", chrome.runtime.lastError.message);
            sendResponse({ status: "error", message: chrome.runtime.lastError.message });
            return;
          }
          chrome.windows.get(win.id, (updated) => {
            console.log("toggleFullscreen: stato dopo update", updated?.state);
            sendResponse({ status: "success", state: updated?.state });
          });
        });
        return;
      }
      if (win.state === "fullscreen") {
        chrome.windows.update(win.id, { state: "normal" }, () => {
          if (chrome.runtime.lastError) {
            console.log("exitFullscreen: errore update", chrome.runtime.lastError.message);
            sendResponse({ status: "error", message: chrome.runtime.lastError.message });
            return;
          }
          chrome.windows.get(win.id, (updated) => {
            console.log("exitFullscreen: stato dopo update", updated?.state);
            sendResponse({ status: "success", state: updated?.state });
          });
        });
      } else {
        sendResponse({ status: "ignored", message: "Finestra non in fullscreen" });
      }
    };

    if (sender?.tab?.id) {
      console.log("toggleFullscreen: tabId da sender", sender.tab.id);
      chrome.tabs.get(sender.tab.id, (tab) => {
        if (chrome.runtime.lastError) {
          console.log("toggleFullscreen: errore tabs.get", chrome.runtime.lastError.message);
          chrome.windows.getCurrent(handleWindow);
          return;
        }
        console.log("toggleFullscreen: windowId da tab", tab?.windowId);
        if (typeof tab?.windowId === "number") {
          chrome.windows.get(tab.windowId, handleWindow);
        } else {
          chrome.windows.getCurrent(handleWindow);
        }
      });
    } else {
      console.log("toggleFullscreen: tabId non disponibile, uso getCurrent");
      chrome.windows.getCurrent(handleWindow);
    }
    return true;
  }
  if (message.type === "salvaConfigurazione") {
    salvaFinestra().then(() => {
      sendResponse({ status: "success", message: "Configurazione salvata!" });
    }).catch((error) => {
      sendResponse({ status: "error", error: error.message });
    });

    // Indica che la risposta sarà inviata in modo asincrono
    return true;
  }

  if (message.type === "eliminaConfigurazione") {
    eliminaConfigurazione().then(() => {
      sendResponse({ status: "success", message: "Configurazione eliminata!" });
    }).catch((error) => {
      sendResponse({ status: "error", error: error.message });
    });

    // indico che la risposta sarà inviata in modo asincrono
    return true;
  }

  if (message.type === "sendToPage") {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      chrome.tabs.sendMessage(tabs[0].id, {
        type: "messageToPage",
        data: message.data
      });
    });
    sendResponse({ status: "success" });
  }

  if (message.action === "salva") {
    salvaFinestra();
  }
  if (message.action === "ripristina") {
    ripristinaFinestra();
    impostaFullScreenCorrente();
  }
  if (message.type === "saveWindowPreferences") {
    salvaFinestra().then(() => {
      sendResponse({ status: "success" });  // Risposta di successo
    }).catch((error) => {
      sendResponse({ status: "error", error: error.message });  // Risposta con errore
    });

    // Importante: restituire true per indicare che la risposta sarà inviata in modo asincrono
    return true;
  }

  if (message.type === "applyWindowPreferences") {
    // Recupera e applica le preferenze
    chrome.storage.local.get("finestraData", (result) => {
      if (result.finestraData) {
        const { left, top, width, height } = result.finestraData;
        chrome.windows.getCurrent((currentWindow) => {
          chrome.windows.update(currentWindow.id, { left, top, width, height }, () => {
            console.log("Preferenze della finestra applicate:", result.finestraData);
            sendResponse({ status: "success", message: "Preferenze applicate!" });
          });
        });
      } else {
        sendResponse({ status: "error", message: "Nessuna preferenza trovata!" });
      }
    });
    return true; // indico che la risposta sarà asincrona
  }
});



